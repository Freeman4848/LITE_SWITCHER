# Lite Switcher v1.1 - Source Code

This directory contains the complete source code for the Windows (Win32) version of Lite Switcher. This version is written in C++ using the native WinAPI.

This project is now considered stable and feature-complete. Future development, including the Linux version, will be part of the upcoming v2.0 rewrite in Rust.

## 📋 Prerequisites

To build this project, you will need:

*   **Microsoft Visual Studio Community 2022** (or higher).
    *   This project was developed and tested on **Version 17.14.17**.
*   The **"Desktop development with C++"** workload installed via the Visual Studio Installer.

## 🛠️ How to Build

1.  Open the `40-LiteSwitcherStartDevelop.sln` file in Visual Studio.
2.  Select the build configuration at the top. The recommended final configuration is **`Release | Win32`**.
3.  From the main menu, select **Build > Rebuild Solution**.
4.  If the build is successful, the final executable will be located in the `Release` folder (`LiteSwitcher.exe`).

## 📁 File Structure

*   `40--LiteSwitcherWork.cpp`: The main application logic, including the keyboard hook, window procedures, and settings dialog logic.
*   `*.h`: Header files containing definitions and resource IDs.
*   `*.rc`: The resource script that defines all UI elements (dialogs, menus, icons).
*   `*.sln` / `*.vcxproj`: Visual Studio solution and project files.
*   `*.ico`: All icon files used by the application.

## 📄 License

This project is distributed under the MIT License. See the main `LICENSE.txt` file for details.