﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by 40-LiteSwitcherStartDevelop.rc
//
#define IDI_APP_ICON                    101
// --- APPLICATION STRINGS ---
#define IDS_APP_TITLE                   103

// --- MAIN DIALOGS AND MENU ---
#define IDR_MAINFRAME                   128
#define IDD_MY40LITESWITCHERSTARTDEVELOP_DIALOG 102
#define IDD_ABOUTBOX                    103
#define IDD_SETTINGS                    111
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDM_SETTINGS                    110
#define IDM_RESTART_HOOK                115 // Добавил ID для перезапуска

// --- TRAY MENU ITEMS ---
#define IDM_TOGGLE_HOOK                 114 // Toggle Hook (Start/Stop)

// --- ICONS ---


#define IDI_TRAY_ACTIVE                 112
#define IDI_TRAY_INACTIVE               113

// --- WINDOW CLASS ID ---
#define IDC_MY40LITESWITCHERSTARTDEVELOP 109

// --- SETTINGS DIALOG CONTROLS ---
// Hotkey 1
#define IDC_KEY_Q                       1001 
#define IDC_HKL_Q                       1002
// Hotkey 2
#define IDC_KEY_W                       1003
#define IDC_HKL_W                       1004
// Hotkey 3
#define IDC_KEY_E                       1005
#define IDC_HKL_E                       1006
// Threshold
#define IDC_SPEED_THRESHOLD             1007

// Hotkey 4 (Новое)
#define IDC_KEY_R                       1016
#define IDC_HKL_R                       1017
// Hotkey 5 (Новое)
#define IDC_KEY_T                       1018
#define IDC_HKL_T                       1019

// Speed Slider (Новое)
#define IDC_SPEED_SLIDER                1015

// --- ABOUT DIALOG CONTROLS ---
#define IDC_STATIC_HELP                 1008 
#define IDC_STATIC_SUPPORT              1009
#define IDC_STATIC_AUTHOR_LABEL         1010
#define IDC_STATIC_AUTHOR_NAME          1011
#define IDC_KOFI_LINK                   1012
#define IDC_GITHUB_LINK                 1013
#define IDC_EMAIL_LINK                  1014
#define IDC_STATIC_DESCRIPTION          1020 // <-- ДОБАВЬТЕ ЭТУ СТРОКУ

// --- COMMON ID ---
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READ_ONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           116
#endif
#endif
