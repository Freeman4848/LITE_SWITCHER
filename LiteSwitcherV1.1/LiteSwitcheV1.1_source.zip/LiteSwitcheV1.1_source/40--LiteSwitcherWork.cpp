﻿// 40-LiteSwitcherStartDevelop.cpp : Defines the entry point for the application.
//

#include "framework.h"
#include "40-LiteSwitcherStartDevelop.h"

// Additional headers for C++ logic and Windows API
#include <map>
#include <chrono>
#include <windows.h>
#include <sstream>
#include <Shellapi.h> // For Shell_NotifyIcon and ShellExecute
#include <cstdio>     // For freopen_s (console)
#include <vector>
#include <string>
#include <set>
#include <locale.h>   // For setlocale
#include <winnt.h>
#include <winuser.h>
#include <Commctrl.h> // For ComboBox and TrackBar
#include <algorithm>  // For std::sort


#pragma comment(lib, "Comctl32.lib") // For controls initialization

// Constants for input fields. Must match Resource.h
#define IDC_SPEED_THRESHOLD     1007
#define IDC_SPEED_SLIDER        1015

#define MAX_LOADSTRING 100
#define MAX_LAYOUTS 5

// Custom IDs and messages
#define WM_TRAY_ICON_MESSAGE (WM_USER + 1)

// =========================================================================
// --- STRUCTURES AND SETTINGS --
// =========================================================================

struct SwitchSetting {
    DWORD vKey;
    HKL hkl;
    WCHAR displayName[50];
};

// Win32 API global variables
HHOOK g_hKeyboardHook = NULL;
HINSTANCE g_hInst; // ИЗМЕНЕНИЕ: Глобальный хендл для всего приложения
WCHAR szTitle[MAX_LOADSTRING];
WCHAR szWindowClass[MAX_LOADSTRING];
HWND g_hWnd = nullptr;

// Lite Switcher logic global variables
std::map<DWORD, std::chrono::steady_clock::time_point> g_lastKeyDownTime;
long long g_doublePressThresholdMs = 250;
bool g_hookActive = true;

std::map<DWORD, SwitchSetting> g_switchSettings;
std::map<HKL, std::wstring> g_installedLayouts;
static HFONT g_hLinkFont = NULL;

// =========================================================================
// --- FUNCTION PROTOTYPES --
// =========================================================================

ATOM                MyRegisterClass();
BOOL                InitInstance(int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    Settings(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam);
std::map<HKL, std::wstring> GetInstalledLayouts();
void InitializeDefaultLayouts();

bool InstallKeyboardHook();
bool UninstallKeyboardHook();
void UpdateTrayIcon(HWND hWnd, bool active);
void ToggleHook(HWND hWnd);
void RestartHook(HWND hWnd);

void SaveSettings();
void LoadSettings();


// =========================================================================
// --- WinMain ENTRY POINT ---
// =========================================================================
int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR lpCmdLine,
    _In_ int nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);
    UNREFERENCED_PARAMETER(hInstance);

#ifdef _DEBUG
    AttachConsole();
#endif

    g_hInst = GetModuleHandle(NULL);

    InitCommonControls();
    LoadSettings();

    LoadStringW(g_hInst, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(g_hInst, IDC_MY40LITESWITCHERSTARTDEVELOP, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass();

    if (!InitInstance(nCmdShow))
    {
        return FALSE;
    }

    if (!InstallKeyboardHook())
    {
        // --- НАШЕ СУПЕР-ОРУЖИЕ: ПОКАЗЫВАЕМ ТОЧНУЮ ПРИЧИНУ ПРОВАЛА ---
        DWORD errorCode = GetLastError();
        WCHAR errorMsg[256];
        swprintf_s(errorMsg, 256,
            L"Failed to install the keyboard hook.\n\n"
            L"Error Code: %lu\n\n"
            L"This usually happens when security software (like Windows Defender) blocks the application.\n\n"
            L"Please try running Lite Switcher as an Administrator.",
            errorCode);

        MessageBox(NULL, errorMsg, L"Lite Switcher - Permission Error", MB_OK | MB_ICONERROR);
        return FALSE;
    }

    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (int)msg.wParam;
}
   
// =========================================================================
// --- HOOK MANAGEMENT FUNCTIONS ---
// =========================================================================

bool InstallKeyboardHook()
{
    if (g_hKeyboardHook != NULL) return true;
    // ИЗМЕНЕНИЕ: Используем глобальный g_hInst
    g_hKeyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, LowLevelKeyboardProc, g_hInst, 0);
    if (g_hKeyboardHook == NULL) return false;
    g_hookActive = true;
    return true;
}



// =========================================================================
// --- DEBUG CONSOLE FUNCTION ---
// =========================================================================

#ifdef _DEBUG
void AttachConsole()
{
    if (GetConsoleWindow() != NULL) return;
    if (AllocConsole())
    {
        SetConsoleOutputCP(CP_UTF8);
        setlocale(LC_ALL, "en_US.UTF-8");
        FILE* fp;
        freopen_s(&fp, "CONOUT$", "w", stdout);
        freopen_s(&fp, "CONOUT$", "w", stderr);
        SetConsoleTitleW(L"Lite Switcher Debug Console (UTF-8)");
        wprintf(L"Lite Switcher: Debug console activated. Hook is starting...\n");
    }
}
#endif

// =========================================================================
// --- SETTINGS SAVE/LOAD FUNCTIONS (REGISTRY) ---
// =========================================================================

const WCHAR* g_szRegKey = L"Software\\LiteSwitcher";

void SaveSettings()
{
    HKEY hKey;
    if (RegCreateKeyEx(HKEY_CURRENT_USER, g_szRegKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL) != ERROR_SUCCESS) return;

    RegSetValueEx(hKey, L"DoublePressThreshold", 0, REG_DWORD, (const BYTE*)&g_doublePressThresholdMs, sizeof(g_doublePressThresholdMs));

    for (int i = 0; i < MAX_LAYOUTS + 5; ++i)
    {
        WCHAR szVKeyName[20], szHklName[20];
        swprintf_s(szVKeyName, L"vKey%d", i);
        swprintf_s(szHklName, L"hkl%d", i);
        RegDeleteValue(hKey, szVKeyName);
        RegDeleteValue(hKey, szHklName);
    }

    int index = 0;
    for (const auto& pair : g_switchSettings)
    {
        if (index >= MAX_LAYOUTS) break;
        WCHAR szVKeyName[20], szHklName[20];
        swprintf_s(szVKeyName, 20, L"vKey%d", index);
        swprintf_s(szHklName, 20, L"hkl%d", index);
        DWORD vKey = pair.first;
        DWORD_PTR hklValue = (DWORD_PTR)pair.second.hkl;
        RegSetValueEx(hKey, szVKeyName, 0, REG_DWORD, (const BYTE*)&vKey, sizeof(vKey));
        RegSetValueEx(hKey, szHklName, 0, REG_QWORD, (const BYTE*)&hklValue, sizeof(hklValue));
        index++;
    }
    RegCloseKey(hKey);
}

void LoadSettings()
{
    g_doublePressThresholdMs = 250;
    InitializeDefaultLayouts();

    HKEY hKey;
    if (RegOpenKeyEx(HKEY_CURRENT_USER, g_szRegKey, 0, KEY_READ, &hKey) != ERROR_SUCCESS)
    {
        wprintf(L"INFO: Registry key not found. Using default settings.\n");
        return;
    }

    DWORD dataSize = sizeof(g_doublePressThresholdMs);
    RegGetValue(hKey, NULL, L"DoublePressThreshold", RRF_RT_REG_DWORD, NULL, &g_doublePressThresholdMs, &dataSize);

    std::map<DWORD, SwitchSetting> loadedSettings;
    for (int i = 0; i < MAX_LAYOUTS; ++i)
    {
        WCHAR szVKeyName[20], szHklName[20];
        swprintf_s(szVKeyName, 20, L"vKey%d", i);
        swprintf_s(szHklName, 20, L"hkl%d", i);
        DWORD vKey;
        DWORD_PTR hklValue;
        DWORD vKeySize = sizeof(vKey);
        DWORD hklSize = sizeof(hklValue);

        if (RegGetValue(hKey, NULL, szVKeyName, RRF_RT_REG_DWORD, NULL, &vKey, &vKeySize) == ERROR_SUCCESS &&
            RegGetValue(hKey, NULL, szHklName, RRF_RT_REG_QWORD, NULL, &hklValue, &hklSize) == ERROR_SUCCESS)
        {
            loadedSettings[vKey] = { vKey, (HKL)hklValue };
        }
    }

    if (!loadedSettings.empty())
    {
        g_switchSettings = loadedSettings;
    }

    RegCloseKey(hKey);
    wprintf(L"INFO: Settings loaded.\n");
}


// --- DEFAULT LAYOUTS INITIALIZATION ---
// =========================================================================

void InitializeDefaultLayouts()
{
    wprintf(L"INFO: Initializing default layouts...\n");
    g_switchSettings.clear();

    std::vector<HKL> availableLayouts;
    int layoutCount = GetKeyboardLayoutList(0, NULL);
    if (layoutCount > 0)
    {
        availableLayouts.resize(layoutCount);
        GetKeyboardLayoutList(layoutCount, availableLayouts.data());
    }

    if (availableLayouts.size() > 0) g_switchSettings['Q'] = { 'Q', availableLayouts[0], L"" };
    if (availableLayouts.size() > 1) g_switchSettings['W'] = { 'W', availableLayouts[1], L"" };
    if (availableLayouts.size() > 2) g_switchSettings['D'] = { 'D', availableLayouts[2], L"" };

    wprintf(L"INFO: Default layouts have been set based on system order.\n");
}

// =========================================================================
// --- HOOK MANAGEMENT FUNCTIONS (продолжение) ---
// =========================================================================

bool UninstallKeyboardHook()
{
    if (g_hKeyboardHook == NULL) return true;
    if (UnhookWindowsHookEx(g_hKeyboardHook))
    {
        g_hKeyboardHook = NULL;
        g_hookActive = false;
        return true;
    }
    return false;
}

void UpdateTrayIcon(HWND hWnd, bool active)
{
    NOTIFYICONDATA nid = {};
    nid.cbSize = sizeof(NOTIFYICONDATA);
    nid.hWnd = hWnd;
    nid.uID = 100;
    nid.uFlags = NIF_ICON | NIF_TIP;

    if (active)
    {
        nid.hIcon = LoadIcon(g_hInst, MAKEINTRESOURCE(IDI_TRAY_ACTIVE));
        wcscpy_s(nid.szTip, L"Lite Switcher: Active ✓. Double-tap a hotkey to switch.");
    }
    else
    {
        nid.hIcon = LoadIcon(g_hInst, MAKEINTRESOURCE(IDI_TRAY_INACTIVE));
        wcscpy_s(nid.szTip, L"Lite Switcher: Stopped ✕");
    }
    Shell_NotifyIcon(NIM_MODIFY, &nid);
}

void ToggleHook(HWND hWnd)
{
    if (g_hookActive)
    {
        if (UninstallKeyboardHook())
        {
            UpdateTrayIcon(hWnd, false);
            MessageBox(hWnd, L"Lite Switcher has been stopped.", L"Information", MB_ICONINFORMATION | MB_TOPMOST);
        }
    }
    else
    {
        if (InstallKeyboardHook())
        {
            UpdateTrayIcon(hWnd, true);
            MessageBox(hWnd, L"Lite Switcher has been started.", L"Information", MB_ICONINFORMATION | MB_TOPMOST);
        }
    }
}

void RestartHook(HWND hWnd)
{
    UninstallKeyboardHook();
    Sleep(100);
    if (InstallKeyboardHook())
    {
        UpdateTrayIcon(hWnd, true);
        MessageBox(hWnd, L"Lite Switcher has been restarted.", L"Information", MB_ICONINFORMATION);
    }
    else
    {
        MessageBox(hWnd, L"Error restarting the hook!", L"Error", MB_ICONERROR);
    }
}

// =========================================================================
// --- LowLevelKeyboardProc (SWITCHING LOGIC) ---
// =========================================================================
LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode != HC_ACTION || !g_hookActive)
    {
        return CallNextHookEx(NULL, nCode, wParam, lParam);
    }

    if (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN)
    {
        KBDLLHOOKSTRUCT* pKey = (KBDLLHOOKSTRUCT*)lParam;
        DWORD vKey = pKey->vkCode;

        if (g_switchSettings.count(vKey))
        {
            auto setting = g_switchSettings.at(vKey);
            auto currentTime = std::chrono::steady_clock::now();
            bool isDoublePress = false;

            if (g_lastKeyDownTime.count(vKey))
            {
                auto lastTime = g_lastKeyDownTime.at(vKey);
                auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(currentTime - lastTime);
                if (duration.count() <= g_doublePressThresholdMs)
                {
                    isDoublePress = true;
                    g_lastKeyDownTime.erase(vKey);
                }
            }

            if (!isDoublePress)
            {
                g_lastKeyDownTime[vKey] = currentTime;
            }
            else
            {
                HWND hForegroundWnd = GetForegroundWindow();
                if (hForegroundWnd) PostMessage(hForegroundWnd, WM_INPUTLANGCHANGEREQUEST, 0, (LPARAM)setting.hkl);

                INPUT inputs[2] = {};
                inputs[0].type = INPUT_KEYBOARD;
                inputs[0].ki.wVk = VK_BACK;
                inputs[1].type = INPUT_KEYBOARD;
                inputs[1].ki.wVk = VK_BACK;
                inputs[1].ki.dwFlags = KEYEVENTF_KEYUP;
                SendInput(2, inputs, sizeof(INPUT));
                return 1;
            }
        }
        else
        {
            if (!g_lastKeyDownTime.empty()) g_lastKeyDownTime.clear();
        }
    }
    return CallNextHookEx(NULL, nCode, wParam, lParam);
}

// =========================================================================
// --- SETTINGS DIALOG LOGIC ---
// =========================================================================

std::map<HKL, std::wstring> GetInstalledLayouts()
{
    std::map<HKL, std::wstring> layouts;
    int count = GetKeyboardLayoutList(0, NULL);
    if (count > 0)
    {
        std::vector<HKL> hkls(count);
        GetKeyboardLayoutList(count, hkls.data());
        for (HKL hkl : hkls)
        {
            LANGID langId = LANGIDFROMLCID((DWORD)(DWORD_PTR)hkl);
            WCHAR langName[256] = { 0 };
            if (GetLocaleInfoW(langId, LOCALE_SLOCALIZEDLANGUAGENAME, langName, 256) > 0)
            {
                layouts[hkl] = langName;
            }
            else
            {
                swprintf_s(langName, 256, L"Layout 0x%04X", (DWORD)(DWORD_PTR)hkl & 0xFFFF);
                layouts[hkl] = langName;
            }
        }
    }
    return layouts;
}

INT_PTR CALLBACK Settings(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
    {
        HWND hSlider = GetDlgItem(hDlg, IDC_SPEED_SLIDER);
        SendMessage(hSlider, TBM_SETRANGE, TRUE, MAKELONG(100, 1000));
        SendMessage(hSlider, TBM_SETPOS, TRUE, (LPARAM)g_doublePressThresholdMs);
        SetDlgItemInt(hDlg, IDC_SPEED_THRESHOLD, (UINT)g_doublePressThresholdMs, FALSE);

        g_installedLayouts = GetInstalledLayouts();

        std::vector<WCHAR> availableKeys = {
            L'Q', L'W', 'E', L'R', L'T', L'A', L'D', L'F', 'G',
            L'Z', L'X', 'C', L'V', 'B'
        };

        int keyComboIds[] = { IDC_KEY_Q, IDC_KEY_W, IDC_KEY_E, IDC_KEY_R, IDC_KEY_T };
        int hklComboIds[] = { IDC_HKL_Q, IDC_HKL_W, IDC_HKL_E, IDC_HKL_R, IDC_HKL_T };

        std::vector<SwitchSetting> currentSettings;
        for (const auto& pair : g_switchSettings)
        {
            currentSettings.push_back(pair.second);
        }
        std::sort(currentSettings.begin(), currentSettings.end(), [](const SwitchSetting& a, const SwitchSetting& b) {
            return a.vKey < b.vKey;
            });

        for (int i = 0; i < MAX_LAYOUTS; ++i)
        {
            HWND hKeyCombo = GetDlgItem(hDlg, keyComboIds[i]);
            HWND hLayoutCombo = GetDlgItem(hDlg, hklComboIds[i]);

            SendMessage(hKeyCombo, CB_ADDSTRING, 0, (LPARAM)L"(None)");
            SendMessage(hKeyCombo, CB_SETITEMDATA, 0, (LPARAM)0);
            for (WCHAR key : availableKeys)
            {
                WCHAR keyStr[2] = { key, L'\0' };
                int idx = (int)SendMessage(hKeyCombo, CB_ADDSTRING, 0, (LPARAM)keyStr);
                SendMessage(hKeyCombo, CB_SETITEMDATA, idx, (LPARAM)(DWORD_PTR)key);
            }

            SendMessage(hLayoutCombo, CB_ADDSTRING, 0, (LPARAM)L"(None)");
            SendMessage(hLayoutCombo, CB_SETITEMDATA, 0, (LPARAM)NULL);
            for (const auto& layout : g_installedLayouts)
            {
                int index = (int)SendMessage(hLayoutCombo, CB_ADDSTRING, 0, (LPARAM)layout.second.c_str());
                SendMessage(hLayoutCombo, CB_SETITEMDATA, index, reinterpret_cast<LPARAM>(layout.first));
            }

            if (i < (int)currentSettings.size())
            {
                for (int j = 0; j < (int)availableKeys.size(); ++j)
                {
                    if (availableKeys[j] == (WCHAR)currentSettings[i].vKey)
                    {
                        SendMessage(hKeyCombo, CB_SETCURSEL, j + 1, 0);
                        break;
                    }
                }

                int layoutIdx = 0;
                for (const auto& layout : g_installedLayouts)
                {
                    if (layout.first == currentSettings[i].hkl)
                    {
                        SendMessage(hLayoutCombo, CB_SETCURSEL, layoutIdx + 1, 0);
                        break;
                    }
                    layoutIdx++;
                }
            }
            else
            {
                SendMessage(hKeyCombo, CB_SETCURSEL, 0, 0);
                SendMessage(hLayoutCombo, CB_SETCURSEL, 0, 0);
            }
        }
        return (INT_PTR)TRUE;
    }

    case WM_HSCROLL:
    {
        if (lParam == (LPARAM)GetDlgItem(hDlg, IDC_SPEED_SLIDER))
        {
            int speed = (int)SendMessage((HWND)lParam, TBM_GETPOS, 0, 0);
            SetDlgItemInt(hDlg, IDC_SPEED_THRESHOLD, speed, FALSE);
        }
    }
    break;

    case WM_COMMAND:
    {
        if (HIWORD(wParam) == EN_CHANGE && LOWORD(wParam) == IDC_SPEED_THRESHOLD)
        {
            BOOL success;
            int speed = GetDlgItemInt(hDlg, IDC_SPEED_THRESHOLD, &success, FALSE);
            if (success)
            {
                HWND hSlider = GetDlgItem(hDlg, IDC_SPEED_SLIDER);
                SendMessage(hSlider, TBM_SETPOS, TRUE, (LPARAM)speed);
            }
        }

        if (LOWORD(wParam) == IDOK)
        {
            BOOL success;
            int speed = GetDlgItemInt(hDlg, IDC_SPEED_THRESHOLD, &success, FALSE);
            g_doublePressThresholdMs = (success && speed >= 100 && speed <= 1000) ? speed : 250;

            std::map<DWORD, SwitchSetting> newSettings;
            std::set<DWORD> usedKeys;
            int keyComboIds[] = { IDC_KEY_Q, IDC_KEY_W, IDC_KEY_E, IDC_KEY_R, IDC_KEY_T };
            int hklComboIds[] = { IDC_HKL_Q, IDC_HKL_W, IDC_HKL_E, IDC_HKL_R, IDC_HKL_T };

            for (int i = 0; i < MAX_LAYOUTS; ++i)
            {
                HWND hKeyCombo = GetDlgItem(hDlg, keyComboIds[i]);
                HWND hLayoutCombo = GetDlgItem(hDlg, hklComboIds[i]);
                int keyIndex = (int)SendMessage(hKeyCombo, CB_GETCURSEL, 0, 0);
                int layoutIndex = (int)SendMessage(hLayoutCombo, CB_GETCURSEL, 0, 0);

                if (keyIndex > 0 && layoutIndex > 0)
                {
                    DWORD vKey = (DWORD)SendMessage(hKeyCombo, CB_GETITEMDATA, keyIndex, 0);
                    if (usedKeys.count(vKey))
                    {
                        MessageBox(hDlg, L"Error: The same hotkey is assigned twice!", L"Configuration Error", MB_ICONERROR);
                        return (INT_PTR)TRUE;
                    }
                    usedKeys.insert(vKey);
                    HKL hkl = reinterpret_cast<HKL>(SendMessage(hLayoutCombo, CB_GETITEMDATA, layoutIndex, 0));
                    SwitchSetting setting = { vKey, hkl, L"" };
                    newSettings[vKey] = setting;
                }
            }
            g_switchSettings = newSettings;
            g_lastKeyDownTime.clear();
            SaveSettings();
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        else if (LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    }
    return (INT_PTR)FALSE;
}

// =========================================================================
// --- ABOUT DIALOG LOGIC ---
// =========================================================================

INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
    {
        LOGFONT lf;
        HFONT hOrigFont = (HFONT)SendDlgItemMessage(hDlg, IDC_STATIC_AUTHOR_NAME, WM_GETFONT, 0, 0);
        GetObject(hOrigFont, sizeof(LOGFONT), &lf);
        lf.lfUnderline = TRUE;
        g_hLinkFont = CreateFontIndirect(&lf);

        SendDlgItemMessage(hDlg, IDC_GITHUB_LINK, WM_SETFONT, (WPARAM)g_hLinkFont, TRUE);
        SendDlgItemMessage(hDlg, IDC_KOFI_LINK, WM_SETFONT, (WPARAM)g_hLinkFont, TRUE);
        SendDlgItemMessage(hDlg, IDC_EMAIL_LINK, WM_SETFONT, (WPARAM)g_hLinkFont, TRUE);

        return (INT_PTR)TRUE;
    }

    case WM_CTLCOLORSTATIC:
    {
        int ctrlId = GetDlgCtrlID((HWND)lParam);
        if (ctrlId == IDC_GITHUB_LINK || ctrlId == IDC_KOFI_LINK || ctrlId == IDC_EMAIL_LINK)
        {
            HDC hdcStatic = (HDC)wParam;
            SetTextColor(hdcStatic, RGB(0, 0, 255));
            SetBkMode(hdcStatic, TRANSPARENT);
            return (INT_PTR)GetStockObject(NULL_BRUSH);
        }
    }
    break;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }

        switch (LOWORD(wParam))
        {
        case IDC_GITHUB_LINK:
            ShellExecute(hDlg, L"open", L"https://github.com/Freeman4848", NULL, NULL, SW_SHOWNORMAL);
            break;
        case IDC_KOFI_LINK:
            ShellExecute(hDlg, L"open", L"https://ko-fi.com/freeman4848", NULL, NULL, SW_SHOWNORMAL);
            break;
        case IDC_EMAIL_LINK:
            ShellExecute(hDlg, L"open", L"mailto:freeman4848.dev@gmail.com", NULL, NULL, SW_SHOWNORMAL);
            break;
        }
        break;

    case WM_DESTROY:
    {
        if (g_hLinkFont) DeleteObject(g_hLinkFont);
        g_hLinkFont = NULL;
        break;
    }
    }
    return (INT_PTR)FALSE;
}

// =========================================================================
// --- STUB FUNCTIONS (Main Window) ---
// =========================================================================

ATOM MyRegisterClass()
{
    WNDCLASSEXW wcex;
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = g_hInst;
    wcex.hIcon = LoadIcon(g_hInst, MAKEINTRESOURCE(IDI_APP_ICON));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_MY40LITESWITCHERSTARTDEVELOP);
    wcex.lpszClassName = szWindowClass;
    return RegisterClassExW(&wcex);
}

BOOL InitInstance(int nCmdShow)
{
    HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, g_hInst, nullptr);
    if (!hWnd) return FALSE;
    g_hWnd = hWnd;

    NOTIFYICONDATA nid = {};
    nid.cbSize = sizeof(NOTIFYICONDATA);
    nid.hWnd = hWnd;
    nid.uID = 100;
    nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nid.uCallbackMessage = WM_TRAY_ICON_MESSAGE;
    nid.hIcon = LoadIcon(g_hInst, MAKEINTRESOURCE(IDI_TRAY_ACTIVE));
    wcscpy_s(nid.szTip, L"Lite Switcher: Active ✓. Double-tap a hotkey to switch.");
    Shell_NotifyIcon(NIM_ADD, &nid);
    return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_TRAY_ICON_MESSAGE:
    {
        if (LOWORD(lParam) == WM_RBUTTONUP)
        {
            POINT pt;
            GetCursorPos(&pt);
            HMENU hMenu = LoadMenu(g_hInst, MAKEINTRESOURCE(IDC_MY40LITESWITCHERSTARTDEVELOP));
            HMENU hSubMenu = GetSubMenu(hMenu, 0);
            if (hSubMenu)
            {
                MENUITEMINFO mii = {};
                mii.cbSize = sizeof(MENUITEMINFO);
                mii.fMask = MIIM_STRING;
                mii.dwTypeData = g_hookActive ? (LPWSTR)L"Stop" : (LPWSTR)L"Start";
                SetMenuItemInfo(hSubMenu, IDM_TOGGLE_HOOK, FALSE, &mii);
                SetForegroundWindow(hWnd);
                TrackPopupMenu(hSubMenu, TPM_LEFTALIGN | TPM_BOTTOMALIGN | TPM_RIGHTBUTTON, pt.x, pt.y, 0, hWnd, NULL);
                PostMessage(hWnd, WM_NULL, 0, 0);
                DestroyMenu(hMenu);
            }
        }
    }
    break;

    case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
        switch (wmId)
        {
        case IDM_TOGGLE_HOOK:
            ToggleHook(hWnd);
            break;
        case IDM_RESTART_HOOK:
            RestartHook(hWnd);
            break;
        case IDM_SETTINGS:
            DialogBox(g_hInst, MAKEINTRESOURCE(IDD_SETTINGS), hWnd, Settings);
            break;
        case IDM_ABOUT:
            DialogBox(g_hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
            break;
        case IDM_EXIT:
            DestroyWindow(hWnd);
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }
    break;

    case WM_DESTROY:
    {
        UninstallKeyboardHook();
        NOTIFYICONDATA nid = {};
        nid.cbSize = sizeof(NOTIFYICONDATA);
        nid.hWnd = hWnd;
        nid.uID = 100;
        Shell_NotifyIcon(NIM_DELETE, &nid);
        PostQuitMessage(0);
    }
    break;

    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}